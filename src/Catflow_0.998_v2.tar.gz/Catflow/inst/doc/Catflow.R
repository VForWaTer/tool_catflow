### R code from vignette source 'Catflow.Rnw'

###################################################
### code chunk number 1: start
###################################################
op <- options()
options(prompt = " ", continue = " ", width=80) #%"R> "
require(xtable)


###################################################
### code chunk number 2: prelim
###################################################
library("Catflow")

exampledir <- file.path(tempdir(),"Catflow-TEST")                                    # project path in a temporary folder
if(!file_test("-d", exampledir)) dir.create(exampledir)                              # create directory
                                                                                     # file path for input directory
indir <- file.path(exampledir, "in")



###################################################
### code chunk number 3: slopelineDecl
###################################################
# northing of slope line 
  north <- seq(1,11, length=20)  
# easting of slope line
  east  <- seq(2, 8, length=20)
# elevation of at points of slope line
  elev  <- approx(c(8,5),n=20)$y + sin((0:19)/2)/5 
# width of slope at points of slope line (here: uniform) 
  slopewidth <- rep(1,20)  


###################################################
### code chunk number 4: slopelineFig
###################################################
opa <- par(mfrow=c(2,1), mar=c(4,4,1,1), lend=1)
plot(north, east, t="b", xlab="Northing", ylab="Easting", 
      ylim=c(1,9), xlim=c(0.5,11.5))           
lines(north,east, col="yellow", lwd=30)
lines(north,east, t="b")     
legend("bottomr", c("slope line","slope area"), pch=c(21,NA), lty=1, lwd=c(1,30), col=c(1,"yellow"), bty="n")
 legend("topl", "Map", lty=0, pch=NA, bty="n")

plot(sqrt((north-1)^2 + (east-2)^2), elev, ylab="Elevation [m]",
xlab="Distance along slope line [m]", t="b",         
ylim=c(4,9), xlim=c(-.5,12.5) )
 legend("bottomleft", "Profile", lty=0, pch=NA, bty="n")
par(opa)


###################################################
### code chunk number 5: slopelistDecl
###################################################
simple.slope <- list( xh = north,
                      yh = east,
                      zh = elev,
                      bh = slopewidth,
                      tot.area = 12 ,
                      htyp = 1, 
                      dyy = 2,
                      xsi = seq(0,1,length = 21),
                      eta = seq(0,1,length = 11),
                      out.file="test.geo"      )                    


###################################################
### code chunk number 6: makeGeom
###################################################
  test.geom <- make.geometry(simple.slope, project.path = indir)   ## interactive plotting causes problems, hence separate chunk ## 


###################################################
### code chunk number 7: plotGeom
###################################################
plot.catf.geometry(test.geom, zooming = FALSE, 
                   ylab="Elevation [m]",
                   xlab="Distance along slope line [m]")


###################################################
### code chunk number 8: facmat
###################################################

  attach(test.geom)   # attach the geometry to make 'eta' and 'xsi' available
  write.facmat(output.file=file.path(indir, "ksmult.dat") )
  write.facmat(output.file=file.path(indir, "thsmult.dat") )


###################################################
### code chunk number 9: soilID
###################################################

# Initial conditions: Uniform Psi (0.8 m) 
  write.facmat(output.file=file.path(indir, "soilhyd.ini"),
               headr=paste("PSI   ", 0,  1, length(eta), length(xsi), 1),
               fac = 0.8)
# Soil type IDs: 
   write.facmat(output.file=file.path(indir, "soils.bod"),
               headr= paste("BODEN",  length(eta), length(xsi), 1),
               fac = matrix(c(rep(1, ceiling(length(eta)/2)),rep(2,floor(length(eta)/2)) ), 
                            nrow = length(eta), ncol = length(xsi))  ) 


###################################################
### code chunk number 10: rain
###################################################

# some artificial rainfall record
  raindat <- data.frame("hours" = seq(0,48, by=0.5),
                        "precip" = c(rep(0,30), 1, rep(3,4), rep(2,3), 
                                      rep(0,25), rep(1,4), rep(0,30)) ) 
  plot(raindat, t="s", ylab="Precip. [mm/h]")
  write.precip(raindat, file.path(indir, "TEST.rain.dat"), 
                start.time= "01.01.2004 00:00:00" )


###################################################
### code chunk number 11: clima
###################################################

 climadat <- data.frame(
              "hours" = seq(0,48, by=0.5),
              "GlobRad" =  ifelse(0 + 800 * sin((seq(0,48, by=0.5) - 8)*pi/12) > 0,
                                  0 + 800 * sin((seq(0,48, by=0.5) - 8)*pi/12),  0),
              "NetRad" = NA ,
              "Temp" = 4 +  sin((seq(0,48, by=0.5) - 12)*pi/12)  ,
              "RelHum" = 70 + 10* sin((seq(0,48, by=0.5))*pi/12) ,
              "vWind"  =  rlnorm(97, 0,1) ,
              "dirWind" = runif(97, 0, 359) 
              )
 write.climate(climadat, file.path(indir, "TEST.clima.dat"), 
                  start.time= "01.01.2004 00:00:00" )


###################################################
### code chunk number 12: printout
###################################################

 write.printout(output.file =  file.path(indir, "printout.prt"), 
                 start.time = "01.01.2004 00:00:00", 
                 end.time = "03.01.2004 00:00:00", 
                 intervall = 0.5, time.unit = "h",
                 flag = 1)


###################################################
### code chunk number 13: surfPob
###################################################

   write.surface.pob(output.file =  file.path(indir, "surface.pob"), 
                    xs = xsi, lu = 33, 
                    windid = rep(1,4))  


###################################################
### code chunk number 14: control
###################################################
 write.control(output.file = "TEST.example.in", project.path = exampledir,    
 start.date = "01.01.2004 00:00:00.00", end.date = "03.01.2004 00:00:00",
 slope.in.list = list( slope1 = list( geo.file = "test.geo", soil.file = "soils.bod", 
                                 ks.fac = "ksmult.dat", ths.fac = "thsmult.dat", 
                                 macro.file = "profil.mak", cv.file = "cont_vol.cv", 
                                 ini.file = "soilhyd.ini",print.file = "printout.prt", 
                                 surf.file = "surface.pob", bc.file = "boundary.rb")) )


###################################################
### code chunk number 15: mainFile
###################################################
 write.CATFLOW.IN(control.files="TEST.example.in", 
                  project.path = exampledir)


###################################################
### code chunk number 16: otherFiles
###################################################
# macro.file = "profil.mak"
 cat(paste("1  0  2", "ari", "0.00 1.00 0.00 1.00 1  1.00 1.00 ", sep="\n"), 
   file = file.path(indir, "profil.mak")  )
# cv.file = "cont_vol.cv" 
 cat(paste("1", "0.8   0.9   0.98   1.0",sep="\n"), 
   file = file.path(indir, "cont_vol.cv")  )
# bc.file = "boundary.rb"
 cat(paste("L", "1  0", "0. 1. 0",   " ",
           "R", "1  0", "0. 1. -10", " ",
           "T", "1  0", "0. 1. -99 "," ",  
           "B", "1  0", "0. 1. 0",   " ",
           "S", "1  0", "0. 1. 0. 1. -99",   " ",
           "M", 0 , sep="\n"),
   file = file.path(indir, "boundary.rb")  )           


###################################################
### code chunk number 17: globalIn
###################################################
  glob.files <-  eval(formals(write.control)$"global.in.list")
  glob.files <-  sapply(glob.files, unclass)[c(4,1,2,3)]
  ID <- names( glob.files) 
  names( glob.files)   <- NULL    
  globdatlist <-  cbind(  ID , glob.files )
  
  globdatlist <-  apply(globdatlist, 1, function(x) paste("\\item ", x[1], ": '", file.path("Catflow-TEST/in", x[2]) ,"'\n", 
                                          sep="") )
  globdatlist <-  gsub("_","\\_",globdatlist, fixed=T)
  cat(globdatlist)


###################################################
### code chunk number 18: windsec
###################################################
  cat(paste("4", "240   0.81", " 50   0.78", " 80   0.97", "220   0.94", sep="\n"),
  file = file.path(indir, "winddir.def") )


###################################################
### code chunk number 19: soiltype
###################################################

 cat(paste("2", "1 Loamy Sand, porosity 0.55, bulk dens 1 g/cm3",
           "1  800  1. 1.  1e-4   0.5 0.34 0.11  20. 0.70  0.050   1. 1. 1.",           
           "4.05e-5  0.55 0.06 12.40 2.28 -6.00 8.00 1000.00 0.80",
           "0. 0. 0.", "0. 0. 0.", "0. 0. 0.", 
           "2 Sandy Clay Loam (30% S, 40 % U; 30 % T)",
           "1  800  1. 1.  1e-4   0.5 0.34 0.11  20. 0.70  0.050   1. 1. 1.",
           "3.42e-6 0.48 0.08 0.96 1.5 -6.00 8.00 1200.00 0.80",
           "0. 0. 0.", "0. 0. 0.", "0. 0. 0.", sep="\n") ,
  file = file.path(indir, "soils.def") )      


###################################################
### code chunk number 20: timeser
###################################################
 cat(paste("PREC", "1", "in/TEST.rain.dat", "",
           "BC", "0", "", "SINKS","0", "", "SOLUTE", "0", "",
           "LAND-USE", "in/landuse/lu_ts.dat", "", 
           "CLIMATE", "1", "in/TEST.clima.dat", "", sep="\n"),
  file = file.path(indir, "timeser.def"))                              ## JW check w/o prepDirs


###################################################
### code chunk number 21: landuse
###################################################

   if(!file_test("-d", file.path(indir, "landuse")) ) dir.create(file.path(indir, "landuse"))
# pointer to land-use parameters
 cat(paste("3", "coniferous forest", "in/landuse/conif.par", sep ="             "),
   file = file.path(indir, "landuse", "lu_file.def") ) 
# time-series of land-use parameters
 cat(paste("01.01.2004 00:00:00.00", "in/landuse/lu_set1.dat", 
            "01.01.2005 00:00:00.00", sep="\n"), 
  file = file.path(indir, "landuse", "lu_ts.dat") )      
# parameters of land-use type 'coniferous forest'
 cat(paste(
      paste("10", "KST", "MAK", "BFI", "BBG", "TWU", "PFH", 
            "PALB", "RSTMIN", "WP_BFW", "F_BFW", sep= "   "),
      "0.    3.     1.    5.    0.95   5.0    5.0     0.15    1.    1.      1.",
      paste(c("1  ","366"), 
            "2.     1.     1.     1.0   1.0    1.0     1.0   546.    0.05    30.",
       sep="    ", collapse="\n"), sep="\n"), 
  file = file.path(indir, "landuse", "conif.par") )
# pointer to surface node attributes
 cat(paste(1, "33  3    %coniferous forest", sep = "\n"),
  file = file.path(indir, "landuse", "lu_set1.dat") )


###################################################
### code chunk number 22: runsim
###################################################
 file.copy(from = system.file("Catflow-TEST/CATFLOW.exe", package = "Catflow"),
           to = exampledir) 
 owd <- setwd(exampledir)                                    # change into dir
 system2("CATFLOW")                                          # run CATFLOW
 setwd(owd)                                                  # change back work dir


###################################################
### code chunk number 23: tidy1
###################################################
detach(test.geom)


###################################################
### code chunk number 24: outdir
###################################################
print(dir(file.path(exampledir, "out")))



###################################################
### code chunk number 25: fileClean (eval = FALSE)
###################################################
## del.files(exampledir, file2del=c("ve.out", "vx.out", "c.out", "gang.out"))


###################################################
### code chunk number 26: batchClean (eval = FALSE)
###################################################
## catf.batch.cleanup(exampledir, indir = "./in", interact = TRUE)


###################################################
### code chunk number 27: ending
###################################################
try(detach(test.geom), silent=TRUE)  # detach test geometry object
options(op)                          # reset options


